import React from 'react';
import PropTypes from 'prop-types';
import { FixedSizeList as List } from 'react-window';
import { FlattenedNode } from './shapes/nodeShapes';
import TreeState, { State } from './state/TreeState';

export default class TreeRenderer extends React.Component {

    getRowCount = () => {
        const { nodes } = this.props;

        return nodes instanceof State ? nodes.flattenedTree.length : nodes.length;
    };

    getNodeDeepness = (node, index) => {
        const { nodes } = this.props;

        if (nodes instanceof State) {
            TreeState.getNodeDeepness(nodes, index);
        }

        return nodes instanceof State ? TreeState.getNodeDeepness(nodes, index) : node.deepness;
    };

    getNode = index => {
        const { nodes } = this.props;

        return nodes instanceof State
            ? { ...TreeState.getNodeAt(nodes, index), deepness: this.getNodeDeepness({}, index) }
            : nodes[index];
    };

    rowRenderer = ({ style, index }) => {
        const { nodeMarginLeft, NodeRenderer } = this.props;
        const node = this.getNode(index);
        return (
            <NodeRenderer
                style={{
                    ...style,
                    marginLeft: node.deepness * nodeMarginLeft,
                    userSelect: 'none',
                    cursor: 'pointer',
                }}
                node={node}
                onChange={this.props.onChange}
                index={index}
            />
        );
    };


    render() {
        const { height, width, scrollToIndex, scrollToAlignment } = this.props;

        return (
            <List
                ref={r => (this._list = r)}
                height={height}
                itemCount={this.props.itemCount}
                itemSize={this.props.itemSize}
                width={width}
                scrollToIndex={scrollToIndex}
                scrollToAlignment={scrollToAlignment}
            >
            {this.rowRenderer}
            </List>
        );
    }
}

TreeRenderer.propTypes = {
    nodes: PropTypes.arrayOf(PropTypes.shape(FlattenedNode)).isRequired,
    NodeRenderer: PropTypes.func.isRequired,
    onChange: PropTypes.func.isRequired,
    nodeMarginLeft: PropTypes.number,
    width: PropTypes.number,
    height: PropTypes.number,
    scrollToIndex: PropTypes.number,
    scrollToAlignment: PropTypes.string,
};

TreeRenderer.defaultProps = {
    width: 50
}
