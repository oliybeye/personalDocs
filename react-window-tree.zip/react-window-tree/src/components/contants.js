export const UPDATE_TYPE = {
    ADD: 0,
    DELETE: 1,
    UPDATE: 2,
  };