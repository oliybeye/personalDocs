import React from 'react';
import { FixedSizeList as List } from 'react-window';
import PropTypes from 'prop-types';
import Expandable from './renderers/Expandable';

class Tree extends React.Component {
    static defaultProps = {
        itemSize: 35
    }
    render() {
        return (
            <List
                height={this.props.height}
                width={this.props.width}
                itemCount={this.props.itemCount}
                itemSize={this.props.itemSize}
            >
                {(index, style) => {
                    return (
                        <>
                            <Expandable>
                            {this.props.children}
                            </Expandable>
                        </>
                    )
                }}
            </List>
        );
    }
}

export default Tree;

Tree.propTypes = {
    children: PropTypes.func.isRequired,
    itemCount: PropTypes.number,
    heigth: PropTypes.number,
    width: PropTypes.number,
    itemSize: PropTypes.number
}