import React, { Component } from 'react';
import Tree from './components/Tree';
import logo from './logo.svg';
import './App.css';
const rowCount = 1000;
class App extends Component {

  count = () => {
    return rowCount;
  }
  render() {
    return (
      <div className="App">
        <Tree
          height={521}
          width={100}
          itemCount={this.count()}
          itemSize={20}
        >
          {({ node, style }) => {
            return <div style={style}>Row {node}</div>
          }}
        </Tree>
      </div>
    );
  }
}

export default App;
