import React, { Component } from 'react';
import Tree from './components/Tree';
import { Nodes } from './sampleTree';
import Expandable from './components/renderers/Expandable';
import './App.css';
const rowCount = 1000;
class App extends Component {
  state = {
    nodes: Nodes
  }

  handleChange = (nodes) => {
    this.setState({ nodes });
  }

  count = () => {
    return rowCount;
  }

  render() {
    return (
      <div className="App">
        <Tree
          height={200}
          width={200}
          itemCount={this.count()}
          itemSize={20}
          nodes={this.state.nodes}
          onChange={this.handleChange}>
          {({ style, node, ...rest }) => (
            <div style={style}>
              <Expandable node={node} {...rest}>
                {node.name}
              </Expandable>
            </div>
          )}
        </Tree>
      </div>
    );
  }
}

export default App;
