import Deletable from './Deletable';
import Expandable from './Expandable';

export default { Deletable, Expandable };